export const environment = {
  production: true,

  // URL of development API
  apiUrl: 'https://goeteplus-zert.de:3000',
  backendUrl: '/backend',
  loginApp: '/login'
};
