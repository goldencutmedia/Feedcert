import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-company-view',
  templateUrl: './company-view.component.html',
  styleUrls: ['./company-view.component.scss'],
  standalone: false
})
export class CompanyViewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
