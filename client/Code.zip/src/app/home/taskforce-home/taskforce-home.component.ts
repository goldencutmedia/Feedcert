import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-taskforce-home',
  templateUrl: './taskforce-home.component.html',
  styleUrls: ['./taskforce-home.component.scss'],
  standalone: false
})
export class TaskforceHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
